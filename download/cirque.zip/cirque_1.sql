-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 16 Janvier 2018 à 07:42
-- Version du serveur :  5.6.20-log
-- Version de PHP :  5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `cirque`
--

-- --------------------------------------------------------

--
-- Structure de la table `accessoire`
--

CREATE TABLE IF NOT EXISTS `accessoire` (
  `NOM` varchar(50) DEFAULT NULL,
  `COULEUR` varchar(50) DEFAULT NULL,
  `VOLUME` float DEFAULT NULL,
  `RATELIER` int(5) DEFAULT NULL,
  `CAMION` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `accessoire`
--

INSERT INTO `accessoire` (`NOM`, `COULEUR`, `VOLUME`, `RATELIER`, `CAMION`) VALUES
('Ballon', 'Rouge', 0.3, 15, 5),
('Barre', 'Blanc', 0.6, 19, 5),
('Fouet', 'Marron', 0.2, 11, 3),
('Bicyclette a elephant', 'Vert', 0.4, 27, 8),
('Trompette', 'Rouge', 0.2, 2, 1),
('Cercle magique', 'Orange', 0.2, 1, 1),
('Boule', 'Cristal', 0.2, 88, 8),
('Cage a lions', 'Noir', 10, 0, 2),
('Chaise longue de lion', 'Bleu', 0.9, 11, 5),
('Peigne de chimpanze', 'Jaune', 0.2, 23, 3),
('Etrier', NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `numero`
--

CREATE TABLE IF NOT EXISTS `numero` (
  `TITRE` varchar(50) DEFAULT NULL,
  `NATURE` varchar(50) DEFAULT NULL,
  `RESPONSABLE` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `numero`
--

INSERT INTO `numero` (`TITRE`, `NATURE`, `RESPONSABLE`) VALUES
('Les Zoupalas', 'Jonglerie', 'Clovis'),
('Le coche infernal', 'Equitation', 'Reine de May'),
('Les fauves', 'Clownerie', 'Louche'),
('Les Smilers', 'Equilibre', 'Attention'),
('La passoire magique', 'Lion', 'Criniere'),
('Les Zozos', 'Clownerie ', 'Jerry'),
('Les Tartarins', 'Jonglerie ', 'Bal');

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

CREATE TABLE IF NOT EXISTS `personnel` (
  `NOM` varchar(50) DEFAULT NULL,
  `ROLE` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `personnel`
--

INSERT INTO `personnel` (`NOM`, `ROLE`) VALUES
('Clovis', 'Jongleur'),
('Reine de May', 'Ecuyer'),
('Louche', 'Clown'),
('Attention', 'Equilibriste'),
('Paritition ', 'Musicien'),
('Criniere', 'Dompteur'),
('Jerry', 'Clown'),
('Bal', 'Jongleur'),
('Final', 'Musicien'),
('Louis', 'Jongleur'),
('Leo', 'Jongleur'),
('Lulu', 'Ecuyer'),
('Coloquinte', 'Equilibriste'),
('Grostas', 'Jongleur'),
('Sangtrespur', 'Dompteur');

-- --------------------------------------------------------

--
-- Structure de la table `utilisation`
--

CREATE TABLE IF NOT EXISTS `utilisation` (
  `TITRE` varchar(50) DEFAULT NULL,
  `UTILISATEUR` varchar(50) DEFAULT NULL,
  `ACCESSOIRE` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `utilisation`
--

INSERT INTO `utilisation` (`TITRE`, `UTILISATEUR`, `ACCESSOIRE`) VALUES
('Les Zoupalas', 'Louis', 'Ballon'),
('Les Zoupalas', 'Leo', 'Ballon'),
('Les Zoupalas', 'Louis', 'Barre'),
('Le coche infernal', 'Grostas', 'Bicyclette a elephant'),
('Le coche infernal', 'Lulu', 'Fouet'),
('Les fauves', 'Jerry', 'Trompette'),
('Les Smilers', 'Attention', 'Cercle magique'),
('Les Smilers', 'Attention', 'Boule'),
('Les Smilers', 'Coloquinte', 'Bicyclette a elephant'),
('La passoire magique', 'Criniere', 'Cage a lions'),
('La passoire magique', 'Criniere', 'Chaise longue de lion'),
('Les Zozos', 'Jerry', 'Bicyclette a elephant'),
('Les Zozos', 'Jerry', 'Peigne de chimpanze'),
('Les Tartarins', 'Grostas', 'Bicyclette a elephant'),
('Le coche infernal', 'Sangtrespur', 'Etrier');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
