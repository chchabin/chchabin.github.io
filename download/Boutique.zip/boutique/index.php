<html>
 <head>
  <title>Boutique FoxShop</title>
  <link href="look.css" rel="stylesheet" type="text/css" />
 </head>
<body>

<div class='titre'><a href='boutique.php'>Boutique <i>FoxSHOP</i></a></div>

<div class='bienvenue'>Welcome</div>

</body>
</html>
