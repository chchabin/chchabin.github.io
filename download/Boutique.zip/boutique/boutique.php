﻿<?php
include("variables.inc.php");

// Traitement des données
$liendb = mysqli_connect($bddserver, $bddlogin, $bddpassword,$bdd);
$sql = "SELECT * FROM $table_produit";
$resultat = mysqli_query ($liendb,$sql);
?>
<!DOCTYPE html>
<html>
	<head>
	  <title>Boutique FoxShop - catalogue</title>
	  <link href="look.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
	<div class='titre'><a href='boutique.php'>Boutique <i>FoxSHOP</i></a></div>
	<table class='catalogue'>
		<thead>
			<th>Nos Produit</th>
			<th>Désignation</th>
			<th>Prix</th>
		</thead>
		<tbody class='liste'> 
			<?php
			// Affichage des données
			while ($produit = mysqli_fetch_array ($resultat, MYSQLI_ASSOC)) {?>
			 <tr>
				<td><?php echo $produit['nom']; ?></td>
				<td class='detail'><?php echo $produit['description']; ?></td>
				<td><?php echo $produit['prix'].' &euro;' ; ?></td>
				<td><img src="img/<?php echo $produit['image'];?>"></td>
			 </tr>	
			<?php } 
			mysqli_free_result($resultat);
			mysqli_close($liendb);?>
		</tbody>
	</table>
	</body>
</html>