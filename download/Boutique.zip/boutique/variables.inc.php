<?php

$bddserver      = "localhost"; //Le serveur de base de données, ne le changer pas
$bddlogin       = "root"; // Mettre votre login de connexion à la base
$bddpassword    = "mysql";// Mettre votre mot de passe de connexion à la base
$bdd            = "boutique";// Le nom de la base qui contient les données, normalement c'est celle que vous avez créé
$table_produit  = "produit";//Le nom de la table qui contient les produits, normalement c'est celle que vous avez importé
$url            = "http://192.168.10.30/";// Le nom du chemin où se trouve votre épertoire web


?>