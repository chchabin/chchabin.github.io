﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrigéLocation
{
    class Categorie
    {
        private string _categLoc;
        private string _description;
        private double _tarifJour;
        private double _mtnCaution;

        public Categorie(string categLoc, string description, double tarifJour, double mtnCaution)
        {
            this._categLoc = categLoc;
            this._description = description;
            this._tarifJour = tarifJour;
            this._mtnCaution = mtnCaution;
        }
        public override string ToString()
        {
            return "Categorie de location : " + this._categLoc + "\n Description : " + this._description + "\nTarif jour : " + this._tarifJour + "\nMontant de la caution" + this._mtnCaution;
        }
    }
}
