﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrigéLocation
{
    class Vehicule
    {
        private string _immatriculation;
        private string _marque;
        private string _modele;
        private string _annee;
        private string _detailPrestation;
        private int _kilometrage;
        private bool _disponibilite;
        private Categorie _categorie;
        public Vehicule(string immatriculation, string marque, string modele, string annee, string detailPrestation, int kilometrage, bool disponibilite)
        {
            this._immatriculation = immatriculation;
            this._marque = marque;
            this._modele = modele;
            this._annee = annee;
            this._detailPrestation = detailPrestation;
            this._kilometrage = kilometrage;
            this._disponibilite = disponibilite;
        }
        public void setCategorie(Categorie c)
        {
            this._categorie = c;
        }
        public string getImmatriculation()
        {
            return this._immatriculation;
        }
        public override string ToString()
        {
            string dispo = this._disponibilite ? "disponible" : "non disponible";

            return "\n--------" + _categorie.ToString() + "\nDétail voiture : " + this._immatriculation + " " + this._marque + " " + this._modele
                + " " + this._annee + " " + this._detailPrestation + " " + this._kilometrage + " " + dispo;
        }
    }
}
