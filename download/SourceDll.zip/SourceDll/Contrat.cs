﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrigéLocation
{
    class Contrat
    {
        private string _numContrat;
        private DateTime _dateContrat;
        private DateTime _datePrise;
        private DateTime _dateRetour;
        private int _kmPrise;
        private int _kmRetour;
        private Vehicule _vehicule;

        public Contrat(string numContrat, DateTime dateContrat, DateTime datePrise, DateTime dateRetour, int kmPrise, int kmRetour)
        {
            this._numContrat = numContrat;
            this._dateContrat = dateContrat;
            this._datePrise = datePrise;
            this._dateRetour = dateRetour;
            this._kmPrise = kmPrise;
            this._kmRetour = kmRetour;

        }
        public void setVehicule(Vehicule v)
        {
            this._vehicule = v;
        }
        public Vehicule getVehicule()
        {
            return this._vehicule;
        }
        public int getAnne()
        {
            return this._dateContrat.Year;
        }
        public string getNumContrat()
        {
            return this._numContrat;
        }
        public override string ToString()
        {
            return this._vehicule.ToString() + "\nContrat \n" + this._numContrat + " " + this._dateContrat + " " + this._datePrise +
                 " " + this._dateRetour + " " + this._kmPrise + " " + this._kmRetour;
        }
        public bool memeVehicule(Contrat c)
        {
           // bool flag = false;
            //if (c.getVehicule().getImmatriculation() == this._vehicule.getImmatriculation())
            //{
            //    flag = true;
            //}

            return (c.getVehicule().getImmatriculation() == this._vehicule.getImmatriculation())?true:false;

        }
    }
}
