﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrigéLocation
{
    class Program
    {
        static void Main(string[] args)
        {
            Client clt1 = new Client("Dupont", "mohammad", 'B', "A114", "rue du charme", "93600", "Aulnay");

            Categorie prem = new Categorie("A", "Premium", 20.00, 1500);

            Vehicule vchl1 = new Vehicule("41AF65", "Opel", "Corsa", "2019", "sans", 1500, true);
            vchl1.setCategorie(prem);

            Vehicule vchl2 = new Vehicule("45sd65", "Citroen", "C5", "2019", "sans", 2500, true);
            vchl2.setCategorie(prem);

            Contrat cntr0 = new Contrat("A1041", new DateTime(2020, 01, 15), new DateTime(2020, 02, 15), new DateTime(2020, 06, 15), 1500, 0);
            cntr0.setVehicule(vchl2);

            Contrat cntr1 = new Contrat("A2045", new DateTime(2020, 05, 15), new DateTime(2020, 05, 15), new DateTime(2020, 06, 15), 1500, 0);
            cntr1.setVehicule(vchl1);

            clt1.AjouterContrat(cntr1);
            clt1.AjouterContrat(cntr0);
            Console.WriteLine(cntr0.ToString());

            Console.WriteLine(cntr1.memeVehicule(cntr0) ? "Les vehicules sont identiques" : "Les vehicules sont différents");

            Console.Write("le vehicule du contrat " + clt1.getNumContrat(cntr0) + " est ");
            Console.WriteLine(clt1.getVehicule(cntr0));

            Console.WriteLine("Les contrats de l'annee 2020");
            Console.WriteLine(clt1.AfficheListe(clt1.getListAnneeContrat(2020)));

            Console.WriteLine("Les contrats de l'annee 2019");
            Console.WriteLine(clt1.AfficheListe(clt1.getListAnneeContrat(2019)));
        }
    }
}
