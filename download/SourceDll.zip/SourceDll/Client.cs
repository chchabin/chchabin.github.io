﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrigéLocation
{
    class Client
    {
        private string _nom;
        private string _prenom;
        private char _typePermis;
        private string _numPermis;
        private string _adresse;
        private string _cp;
        private string _ville;
        private List<Contrat> mesContrats;

        public Client(string nom, string prenom, char typePermis, string numPermis, string adresse, string cp, string ville)
        {
            this._nom = nom;
            this._prenom = prenom;
            this._typePermis = typePermis;
            this._numPermis = numPermis;
            this._adresse = adresse;
            this._cp = cp;
            this._ville = ville;
            this.mesContrats = new List<Contrat>();
        }
        public void AjouterContrat(Contrat c)
        {
            mesContrats.Add(c);
        }
        public string getNumContrat(Contrat c)
        {
            string numC = "Inconnue";
            foreach (Contrat cntr in mesContrats)
            {
                if (cntr.getNumContrat() == c.getNumContrat())
                {
                    numC = c.getNumContrat();
                }

            }
            return numC;
        }
        public List<Contrat> getListAnneeContrat(int annee)
        {
            List<Contrat> anneeContrat = new List<Contrat>();
            foreach (Contrat cntr in mesContrats)
            {
                if (cntr.getAnne() == annee)
                {
                    anneeContrat.Add(cntr);
                }
            }
            return anneeContrat;
        }
        public string AfficheListe(List<Contrat> maliste)
        {
            string rep = "";
            foreach (Contrat cntr in maliste)
            {
                rep += cntr.ToString() + "\n##########\n ";
            }
            return (rep == "") ? "Pas de contrats" : rep;
        }
        public string getVehicule(Contrat c)
        {
            string plaque = "Inconnue";
            foreach (Contrat cntr in mesContrats)
            {
                if (cntr.getVehicule().getImmatriculation() == c.getVehicule().getImmatriculation())
                {
                    plaque = c.getVehicule().getImmatriculation();
                }

            }
            return plaque;
        }
    }
}
